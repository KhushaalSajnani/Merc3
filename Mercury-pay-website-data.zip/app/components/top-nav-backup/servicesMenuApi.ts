const ServicesMenuApi = [
    {
        "id": 1,
        "CatagoryTitle": "Migrations",
        "heroImageSrc": "",
        "heroContentLink": "",
        "Contents": [
            { 
                "id": 1, 
                "imageSrc": "",
                "videoSrcImage": "",
                "imageAlt": "icon", 
                "titleText": "Email migrations to Microsoft 365",
                "subText": "",
                "contentLink": "",
            },
        ],
    },
];

export default ServicesMenuApi; 