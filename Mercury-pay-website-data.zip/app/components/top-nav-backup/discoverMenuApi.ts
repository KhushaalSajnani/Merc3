const DiscoverMenuApi = [
    {
        id: 1,
        link: "/singhular-talks",
        image: "https://react.dev/images/home/community/react_india_selfie.webp",
        title: "Singhular Talks",
    },
    {
        id: 2,
        link: "/articles",
        image: "https://react.dev/images/home/community/react_india_selfie.webp",
        title: "Articles",
    },
    {
        id: 3,
        link: "/webinars",
        image: "https://react.dev/images/home/community/react_india_selfie.webp",
        title: "Webinars",
    },
    {
        id: 4,
        link: "/seminars",
        image: "https://react.dev/images/home/community/react_india_selfie.webp",
        title: "Seminars",
    },
    {
        id: 5,
        link: "/newsletters",
        image: "https://react.dev/images/home/community/react_india_selfie.webp",
        title: "Newsletters",
    },
    {
        id: 6,
        link: "/podcasts",
        image: "https://react.dev/images/home/community/react_india_selfie.webp",
        title: "Podcasts",
    },
];

export default DiscoverMenuApi; 