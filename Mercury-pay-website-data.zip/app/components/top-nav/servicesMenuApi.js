const ServicesMenuApi = [
    {
        id: 1,
        link: "/pages/mercury360",
        title: "Mercury 360",
        description: "Simplifying payments with managed services", 
    },
    {
        id: 2,
        link: "/pages/mercury-hub",
        title: "Mercury Hub",
        description: "Jumpstarting the card payment scheme journey", 
    },
];

export default ServicesMenuApi; 