const FeaturedVideoApi = [
    {
        id: 1,
        headingTitle: "",
        subText: "",
        videoURL: "/assets/videos/mercury-pay-promo.mp4",
        videoURLYouTube: "",
    },
];

export default FeaturedVideoApi;



